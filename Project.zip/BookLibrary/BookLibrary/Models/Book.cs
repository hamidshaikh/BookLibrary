﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BookLibrary.Models
{
    public class Book
    {
        public int Id { get; set; }
        [Required]
        public string ISBN { get; set; }
        [Required]
        [DisplayName("Author Name")]
        public string AuthorName { get; set; }
        [Required]
        [DisplayName("Publisher Name")]
        public string PublisherName { get; set; }
        [Required]
        [DisplayName("Publisher Year")]
        public int PublisherYear { get; set; }
    }
}
