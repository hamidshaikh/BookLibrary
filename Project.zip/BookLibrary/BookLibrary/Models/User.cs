﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BookLibrary.Models
{
    public class User
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "First Name required")]
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last Name required")]
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email Address Required")]
        [EmailAddress(ErrorMessage = "Invalid Email address")]
        [DisplayName("Email Address")]
        public string EmailId { get; set; }
        [DisplayName("Mobile Number")]
        [MinLength(10, ErrorMessage = "Please provide 10 digit mobile number")]
        [MaxLength(10, ErrorMessage = "Please provide 10 digit mobile number")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "Country is required")]
        public string Country { get; set; }
    }
}
