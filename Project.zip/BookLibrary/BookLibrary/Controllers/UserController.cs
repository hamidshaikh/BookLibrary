﻿using BookLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace BookLibrary.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        string connString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        public ActionResult Register()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Register(User user)
        {
            int status = 0;
            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        conn.Open();
                        string cmdText = "insert into UserAccount values (@FirstName, @LastName, @EmailId, @MobileNumber, @Country)";
                        SqlCommand cmd = new SqlCommand(cmdText, conn);

                        cmd.Parameters.AddWithValue("@FirstName", user.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", user.LastName);
                        cmd.Parameters.AddWithValue("@EmailId", user.EmailId);
                        cmd.Parameters.AddWithValue("@MobileNumber", user.MobileNumber);
                        cmd.Parameters.AddWithValue("@Country", user.Country);

                        status = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    return View();
                }

                if (status > 0)
                    return RedirectToAction("Login");
                else
                    return View();
            }

            return View();
        }

        public ActionResult Login()
        {
            if (Convert.ToBoolean(Session["IsUserLogin"]) != null && Convert.ToBoolean(Session["IsUserLogin"]))
            {
                return RedirectToAction("BookList", "Book");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(User user, string password)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string cmdText = "select Email from UserAccount Where Email = @EmailId";
                    SqlCommand cmd = new SqlCommand(cmdText, conn);
                    cmd.Parameters.AddWithValue("@EmailId", user.EmailId);
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.HasRows && password == "test123")
                    {
                        @ViewBag.Message = "";
                        Session["isUserLogin"] = true;
                        return RedirectToAction("BookList", "Book", new { @email = user.EmailId });
                    }
                    else
                    {
                        @ViewBag.Message = "Invalid User Name or Password";
                        Session["isUserLogin"] = false;
                        return View();
                    }

                }
            }
            catch (Exception ex)
            {
                @ViewBag.Message = ex.Message.ToString();
                Session["isUserLogin"] = false;
                return View();
            }
        }

        public ActionResult Logout()
        {
            Session["isUserLogin"] = false;
            return RedirectToAction("Login");
        }
    }
}
