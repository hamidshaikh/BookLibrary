﻿using BookLibrary.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookLibrary.Controllers
{
    public class BookController : Controller
    {
        //
        // GET: /Book/

        string connString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        public ActionResult BookList(string email)
        {
            if (!Convert.ToBoolean(Session["IsUserLogin"]))
            {
                return RedirectToAction("Login", "User");
            }

            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    string cmdText = "select * from Book";

                    SqlDataAdapter da = new SqlDataAdapter(cmdText, conn);
                    da.Fill(dt);

                    return View(dt);
                }
            }
            catch (Exception ex)
            {
                @ViewBag.Message = ex.Message.ToString();
                return View();
            }
        }

        public ActionResult AddBook()
        {
            if (!Convert.ToBoolean(Session["IsUserLogin"]))
            {
                return RedirectToAction("Login", "User");
            }

            return View();
        }

        
        [HttpPost]
        public ActionResult AddBook(Book book)
        {
            if (!Convert.ToBoolean(Session["IsUserLogin"]))
            {
                return RedirectToAction("Login", "User");
            }

            int status = 0;
            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        conn.Open();
                        string cmdText = "insert into Book values (@ISBN, @AuthorName, @PublisherName, @PublisherYear)";
                        SqlCommand cmd = new SqlCommand(cmdText, conn);

                        cmd.Parameters.AddWithValue("@ISBN", book.ISBN);
                        cmd.Parameters.AddWithValue("@AuthorName", book.AuthorName);
                        cmd.Parameters.AddWithValue("@PublisherName", book.PublisherName);
                        cmd.Parameters.AddWithValue("@PublisherYear", book.PublisherYear);

                        status = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    return View();
                }

                if (status > 0)
                    return RedirectToAction("BookList");
                else
                    return View();
            }
            return View();

        }
    }
}
